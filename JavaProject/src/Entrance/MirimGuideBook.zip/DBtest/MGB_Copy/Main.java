package MGB_Copy;

public class Main {
	public static void main(String[] args) {
		DBConnection connection = new DBConnection();
		System.out.println("�����ڿ���: "+connection.isAdmin("admin", "admin"));
		
		
		
	}
}
